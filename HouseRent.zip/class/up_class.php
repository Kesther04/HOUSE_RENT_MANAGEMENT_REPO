
<?php
    //class for updating data in database
    class UPD
    {
        
    }

?>