<?php

// to connect to the database server
$con = new mysqli("localhost","root","","house_rent_db");

?>